Static website for Tiiny.host or Netlify.
Contains:
- index.html (main site)
- googleb236932e56252b01.html (Google verification file)
Upload ZIP to Tiiny.host and then verify in Google Search Console.
